import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/poo_2"
                                       , "root"
                                       , "univille");
            System.out.println("Conectou no banco com sucesso!");
            /*
            String insert = "insert into pessoa(nome,sobrenome,idade,altura)" +
                    " values('Tom','Cruise',61,1.78)";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(insert);
            */
            String delete = "delete from pessoa";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(delete);
        } catch (Exception e) {
            System.out.println("Deu erro.");
            e.printStackTrace();
        }
    }

}
